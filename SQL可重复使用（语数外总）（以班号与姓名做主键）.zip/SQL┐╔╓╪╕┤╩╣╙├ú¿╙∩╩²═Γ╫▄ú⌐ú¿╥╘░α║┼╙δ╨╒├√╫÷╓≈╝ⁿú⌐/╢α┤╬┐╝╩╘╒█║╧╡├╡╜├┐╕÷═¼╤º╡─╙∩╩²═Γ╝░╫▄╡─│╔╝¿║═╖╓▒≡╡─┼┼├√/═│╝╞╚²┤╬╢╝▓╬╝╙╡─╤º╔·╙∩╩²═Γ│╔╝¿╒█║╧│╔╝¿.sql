/*三次考试均参加成员统计语数外成绩
作用：统计三次考试均参加成员语数外成绩
对三次考试成绩的语数外每一门（比如语文）。三次成绩按照3:3:4的权重计算最终的语文成绩，数学英语同理，
然后把语数外最终成绩相加得到最终成绩
得到的表结构列名：classNumber	NAME	firstChinese	firstMath	firstEnglish  （第一次考试的语数外成绩）	
middleChinese	middleMath	middleEnglish	（第二次考试的语数外成绩）	
endChinese	endMath	endEnglish	（第三次考试的语数外成绩）	
ActualChinese	ChineseRank	
ActualMath	MathRank	
ActualEnglish	EnglishRank	
totalScore	totalRank


使用要求：
对表的要求
firstTest:列名：
classNumber	name	Chinese	Math	English	totalScore

middle:列名：
classNumber	name	Chinese	Math	English	totalScore

endTest:
classNumber	name	Chinese	Math	English	totalScore
使用时需要改变：
firstTest：第一次考试成绩
middle：第二次考试成绩
endTest：第三次考试成绩
*/

/*
可以在前面加上insert into actualscore（actualscore为整理后的每个学生原始成绩与折合成绩及折合后的语数外总的成绩排名）
*/
SELECT 
classNumber, NAME, 
firstTest.`Chinese` AS firstChinese,
firstTest.`Math` AS firstMath,
firstTest.`English` AS firstEnglish,
middle.`Chinese` AS middleChinese,
middle.`Math` AS middleMath,
middle.`English` AS middleEnglish,
endTest.`Chinese` AS endChinese,
endTest.`Math` AS endMath,
endTest.`English` AS endEnglish,
(firstTest.`Chinese` * 0.3 + middle.`Chinese`*0.3+endTest.`Chinese`*0.4) AS ActualChinese,
rank() over (ORDER BY ((firstTest.`Chinese` * 0.3 + middle.`Chinese`*0.3+endTest.`Chinese`*0.4)) DESC) AS ChineseRank,
(firstTest.`Math` * 0.3 + middle.`Math`*0.3+endTest.`Math`*0.4) AS ActualMath,
rank() over (ORDER BY ((firstTest.`Math` * 0.3 + middle.`Math`*0.3+endTest.`Math`*0.4)) DESC) AS MathRank,
(firstTest.`English` * 0.3 + middle.`English`*0.3+endTest.`English`*0.4) AS ActualEnglish,
rank() over (ORDER BY ((firstTest.`English` * 0.3 + middle.`English`*0.3+endTest.`English`*0.4)) DESC) AS EnglishRank,
((firstTest.`English` * 0.3 + middle.`English`*0.3+endTest.`English`*0.4) + 
(firstTest.`Chinese` * 0.3 + middle.`Chinese`*0.3+endTest.`Chinese`*0.4) + 
+ (firstTest.`Math` * 0.3 + middle.`Math`*0.3+endTest.`Math`*0.4)
) AS totalScore,
rank() over (ORDER BY ((firstTest.`English` * 0.3 + middle.`English`*0.3+endTest.`English`*0.4) + 
(firstTest.`Chinese` * 0.3 + middle.`Chinese`*0.3+endTest.`Chinese`*0.4) + 
+ (firstTest.`Math` * 0.3 + middle.`Math`*0.3+endTest.`Math`*0.4)
) DESC) AS totalRank

FROM
  (firstTest JOIN middle USING(classNumber, NAME)) JOIN endTest USING(classNumber, NAME);