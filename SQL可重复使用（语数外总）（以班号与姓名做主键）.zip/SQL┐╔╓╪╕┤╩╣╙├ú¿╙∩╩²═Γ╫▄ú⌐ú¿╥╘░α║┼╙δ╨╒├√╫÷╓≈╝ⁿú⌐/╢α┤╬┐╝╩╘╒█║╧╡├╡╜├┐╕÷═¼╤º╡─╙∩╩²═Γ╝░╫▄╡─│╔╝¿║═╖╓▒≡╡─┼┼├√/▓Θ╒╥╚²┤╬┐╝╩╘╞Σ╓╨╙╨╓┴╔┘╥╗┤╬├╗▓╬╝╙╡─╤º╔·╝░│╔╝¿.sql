/*
作用：统计三次考试至少有一次没有参加的学生
得到的表结构列名classNumber	name	Chinese	Math	English	totalScore


使用要求：attendthreetest(参加了三次考试的学生表)，列名
classNumber	NAME
使用时需要改变：firstTest，middle，endTest
*/
#得到参加了第一次考试，但是没有参加完三次考试的名单
#firstTest为第一次考试的学生成绩表，列名：classNumber	name	Chinese	Math	English	totalScore
SELECT
*
FROM
  firstTest
WHERE (firstTest.classNumber,firstTest.`name`) NOT IN (SELECT classNumber,NAME FROM attendthreetest);

#得到参加了第二次考试，但是没有参加完三次考试的名单
#middle为第二次考试的学生成绩表，列名：classNumber	name	Chinese	Math	English	totalScore
SELECT
*
FROM
  middle
WHERE (middle.classNumber,middle.`name`) NOT IN (SELECT classNumber,NAME FROM attendthreetest);

#得到参加了第三次考试，但是没有参加完三次考试的名单
#endTest为第三次考试的学生成绩表，列名：classNumber	name	Chinese	Math	English	totalScore
SELECT
*
FROM
  endTest
WHERE (endTest.classNumber,endTest.`name`) NOT IN (SELECT classNumber,NAME FROM attendthreetest);