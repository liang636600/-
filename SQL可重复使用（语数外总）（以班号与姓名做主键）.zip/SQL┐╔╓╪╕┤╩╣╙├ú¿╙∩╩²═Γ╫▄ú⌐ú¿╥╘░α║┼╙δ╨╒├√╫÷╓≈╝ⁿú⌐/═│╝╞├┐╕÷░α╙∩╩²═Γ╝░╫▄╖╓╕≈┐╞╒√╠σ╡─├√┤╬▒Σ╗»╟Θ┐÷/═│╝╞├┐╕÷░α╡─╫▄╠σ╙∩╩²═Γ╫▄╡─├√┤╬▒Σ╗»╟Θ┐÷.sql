/*
作用：统计每一个班在两次考试中名次变化情况
得到的表结构列名classNumber	ClassChineseChange	ClassMathChange	ClassEnglishChange	ClassTotalChange


使用要求：actualstudentrankchangelast表

3.步骤三中需要使用（（（actualstudentrankchangelast表，列名：
classNumber	NAME	ChineseRank1	ChineseRank2	ChineseRankChange	MathRank1	MathRank2	MathRankChange	
EnglishRank1	EnglishRank2	EnglishRankChange	totalRank1	totalRank2	totalRankChange

）））
使用时需要改变：actualstudentrankchangelast
*/

#统计一个班上的名次的变化情况(这里使用每个学生的变化情况相加)
#产生一个每个班的各科总的语数外总成绩的变化情况
#列名：
#classNumber	ClassChineseChange	ClassMathChange	ClassEnglishChange	ClassTotalChange
SELECT
classNumber,SUM(ChineseRankChange) AS ClassChineseChange,SUM(MathRankChange) AS ClassMathChange,
SUM(EnglishRankChange)  AS ClassEnglishChange,SUM(totalRankChange) AS ClassTotalChange
FROM
actualstudentrankchangelast
GROUP BY
classNumber