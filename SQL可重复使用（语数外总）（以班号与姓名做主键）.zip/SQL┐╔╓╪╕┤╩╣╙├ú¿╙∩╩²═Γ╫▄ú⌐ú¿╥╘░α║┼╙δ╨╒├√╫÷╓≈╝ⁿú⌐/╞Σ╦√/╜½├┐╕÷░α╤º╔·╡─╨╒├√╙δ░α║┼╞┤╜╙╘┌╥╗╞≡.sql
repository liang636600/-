/*
作用：主要是将第一张成绩单里名字（第一张成绩单里名字与班级错误）和对应班级拼在一起
下面总共有18各班
得到：stuAndClass表即学生与正确班级对应表
需要：c1到c18的班级名单，如c1中是一班的同学名单
*/

INSERT INTO stuAndClass (
SELECT
*
FROM
c1);

INSERT INTO stuAndClass (
SELECT
*
FROM
c2);
INSERT INTO stuAndClass (
SELECT
*
FROM
c3);
INSERT INTO stuAndClass (
SELECT
*
FROM
c4);
INSERT INTO stuAndClass (
SELECT
*
FROM
c5);
INSERT INTO stuAndClass (
SELECT
*
FROM
c6);
INSERT INTO stuAndClass (
SELECT
*
FROM
c7);
INSERT INTO stuAndClass (
SELECT
*
FROM
c8);
INSERT INTO stuAndClass (
SELECT
*
FROM
c9);
INSERT INTO stuAndClass (
SELECT
*
FROM
c10);
INSERT INTO stuAndClass (
SELECT
*
FROM
c11);
INSERT INTO stuAndClass (
SELECT
*
FROM
c12);
INSERT INTO stuAndClass (
SELECT
*
FROM
c13);
INSERT INTO stuAndClass (
SELECT
*
FROM
c14);
INSERT INTO stuAndClass (
SELECT
*
FROM
c15);
INSERT INTO stuAndClass (
SELECT
*
FROM
c16);
INSERT INTO stuAndClass (
SELECT
*
FROM
c17);
INSERT INTO stuAndClass (
SELECT
*
FROM
c18);
