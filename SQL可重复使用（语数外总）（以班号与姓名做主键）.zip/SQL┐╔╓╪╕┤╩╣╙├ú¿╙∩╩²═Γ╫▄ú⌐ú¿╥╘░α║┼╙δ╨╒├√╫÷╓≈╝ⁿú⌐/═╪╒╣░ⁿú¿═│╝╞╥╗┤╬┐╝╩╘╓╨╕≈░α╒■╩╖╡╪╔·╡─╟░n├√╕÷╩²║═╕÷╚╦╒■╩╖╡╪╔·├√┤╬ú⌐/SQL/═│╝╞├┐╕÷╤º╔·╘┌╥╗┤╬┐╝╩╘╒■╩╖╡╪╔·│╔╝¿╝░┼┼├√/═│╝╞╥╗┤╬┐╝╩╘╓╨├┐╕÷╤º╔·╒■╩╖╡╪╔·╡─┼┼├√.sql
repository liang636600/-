#1.统计每个学生政史地生的排名
SELECT
NAME,classNumber,
politics,
rank() over (ORDER BY ((politics)) DESC) AS politicsRank,
history,
rank() over (ORDER BY ((history)) DESC) AS historyRank,
geography,
rank() over (ORDER BY ((geography)) DESC) AS geographyRank,
biology,
rank() over (ORDER BY (biology) DESC) AS biologyRank
FROM
endtest;
