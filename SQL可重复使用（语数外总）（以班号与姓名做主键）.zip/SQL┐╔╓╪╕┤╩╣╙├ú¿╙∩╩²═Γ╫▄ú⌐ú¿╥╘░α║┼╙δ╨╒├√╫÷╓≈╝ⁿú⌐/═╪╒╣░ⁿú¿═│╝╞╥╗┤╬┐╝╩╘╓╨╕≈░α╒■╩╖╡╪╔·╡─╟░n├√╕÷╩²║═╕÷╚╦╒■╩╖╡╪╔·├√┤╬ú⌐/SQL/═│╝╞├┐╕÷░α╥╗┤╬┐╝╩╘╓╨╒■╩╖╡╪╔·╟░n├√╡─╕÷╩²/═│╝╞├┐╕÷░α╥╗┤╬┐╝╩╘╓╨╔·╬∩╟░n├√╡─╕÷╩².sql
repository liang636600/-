/*
作用：统计某次考试各班的政治前n名个数
得到的表结构列名classNumber	countNumbiology10	countNumbiology20	countNumbiology50	countNumbiology100	countNumbiology200	
countNumbiology300	countNumbiology400	countNumbiology500	countNumbiology600	countNumbiology700	countNumbiology800	
countNumbiology900	countNumbiology1000

使用要求：endteststupoliticshistorygeographybiologyscoreandrank(学生成绩表)，列名
NAME	classNumber	politics	politicsRank	history	historyRank	geography	geographyRank	biology	biologyRank

使用时需要改变：endteststupoliticshistorygeographybiologyscoreandrank表名改变为成绩所在的表
*/


/*
如果是想直接往firstbiologyclassranktopn这个表中插入数据，那么可以在前面加上insert into firstbiologyclassranktopn语句
*/
SELECT * 
FROM
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology10
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <= 10
GROUP BY
  classNumber) AS a) AS top10



JOIN
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology20
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <= 20
GROUP BY
  classNumber) AS a) AS top20 USING(classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology50
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <= 50
GROUP BY
  classNumber) AS a) AS top50 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology100
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=100
GROUP BY
  classNumber) AS a) AS top100 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology200
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=200
GROUP BY
  classNumber) AS a) AS top200 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology300
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=300
GROUP BY
  classNumber) AS a) AS top300 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology400
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=400
GROUP BY
  classNumber) AS a) AS top400 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology500
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=500
GROUP BY
  classNumber) AS a) AS top500 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology600
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=600
GROUP BY
  classNumber) AS a) AS top600 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology700
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=700
GROUP BY
  classNumber) AS a) AS top700 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology800
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=800
GROUP BY
  classNumber) AS a) AS top800 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology900
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=900
GROUP BY
  classNumber) AS a) AS top900 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumbiology1000
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
biologyRank <=1000
GROUP BY
  classNumber) AS a) AS top1000 USING (classNumber)


