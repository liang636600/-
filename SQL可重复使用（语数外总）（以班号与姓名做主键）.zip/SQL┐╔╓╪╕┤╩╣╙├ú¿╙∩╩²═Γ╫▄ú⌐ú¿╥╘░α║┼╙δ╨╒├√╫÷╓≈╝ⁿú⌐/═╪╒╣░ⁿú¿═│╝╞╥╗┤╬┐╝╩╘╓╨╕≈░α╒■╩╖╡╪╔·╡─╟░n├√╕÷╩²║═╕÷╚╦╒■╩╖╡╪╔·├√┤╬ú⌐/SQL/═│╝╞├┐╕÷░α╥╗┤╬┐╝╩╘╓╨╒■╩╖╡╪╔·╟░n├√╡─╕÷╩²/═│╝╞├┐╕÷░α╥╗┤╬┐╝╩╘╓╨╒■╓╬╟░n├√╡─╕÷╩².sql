/*
作用：统计某次考试各班的政治前n名个数
得到的表结构列名classNumber	countNumpolitics10	countNumpolitics20	countNumpolitics50	countNumpolitics100	countNumpolitics200	
countNumpolitics300	countNumpolitics400	countNumpolitics500	countNumpolitics600	countNumpolitics700	countNumpolitics800	
countNumpolitics900	countNumpolitics1000

使用要求：endteststupoliticshistorygeographybiologyscoreandrank(学生成绩表)，列名
NAME	classNumber	politics	politicsRank	history	historyRank	geography	geographyRank	biology	biologyRank

使用时需要改变：endteststupoliticshistorygeographybiologyscoreandrank表名改变为成绩所在的表
*/


/*
如果是想直接往firstpoliticsclassranktopn这个表中插入数据，那么可以在前面加上insert into firstpoliticsclassranktopn语句
*/
SELECT * 
FROM
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics10
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <= 10
GROUP BY
  classNumber) AS a) AS top10



JOIN
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics20
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <= 20
GROUP BY
  classNumber) AS a) AS top20 USING(classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics50
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <= 50
GROUP BY
  classNumber) AS a) AS top50 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics100
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=100
GROUP BY
  classNumber) AS a) AS top100 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics200
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=200
GROUP BY
  classNumber) AS a) AS top200 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics300
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=300
GROUP BY
  classNumber) AS a) AS top300 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics400
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=400
GROUP BY
  classNumber) AS a) AS top400 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics500
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=500
GROUP BY
  classNumber) AS a) AS top500 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics600
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=600
GROUP BY
  classNumber) AS a) AS top600 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics700
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=700
GROUP BY
  classNumber) AS a) AS top700 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics800
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=800
GROUP BY
  classNumber) AS a) AS top800 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics900
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=900
GROUP BY
  classNumber) AS a) AS top900 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumpolitics1000
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
politicsRank <=1000
GROUP BY
  classNumber) AS a) AS top1000 USING (classNumber)


