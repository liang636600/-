/*
作用：统计某次考试各班的政治前n名个数
得到的表结构列名classNumber	countNumgeography10	countNumgeography20	countNumgeography50	countNumgeography100	countNumgeography200	
countNumgeography300	countNumgeography400	countNumgeography500	countNumgeography600	countNumgeography700	countNumgeography800	
countNumgeography900	countNumgeography1000

使用要求：endteststupoliticshistorygeographybiologyscoreandrank(学生成绩表)，列名
NAME	classNumber	politics	politicsRank	history	historyRank	geography	geographyRank	biology	biologyRank

使用时需要改变：endteststupoliticshistorygeographybiologyscoreandrank表名改变为成绩所在的表
*/


/*
如果是想直接往firstgeographyclassranktopn这个表中插入数据，那么可以在前面加上insert into firstgeographyclassranktopn语句
*/
SELECT * 
FROM
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography10
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <= 10
GROUP BY
  classNumber) AS a) AS top10



JOIN
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography20
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <= 20
GROUP BY
  classNumber) AS a) AS top20 USING(classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography50
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <= 50
GROUP BY
  classNumber) AS a) AS top50 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography100
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=100
GROUP BY
  classNumber) AS a) AS top100 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography200
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=200
GROUP BY
  classNumber) AS a) AS top200 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography300
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=300
GROUP BY
  classNumber) AS a) AS top300 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography400
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=400
GROUP BY
  classNumber) AS a) AS top400 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography500
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=500
GROUP BY
  classNumber) AS a) AS top500 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography600
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=600
GROUP BY
  classNumber) AS a) AS top600 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography700
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=700
GROUP BY
  classNumber) AS a) AS top700 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography800
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=800
GROUP BY
  classNumber) AS a) AS top800 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography900
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=900
GROUP BY
  classNumber) AS a) AS top900 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumgeography1000
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  endteststupoliticshistorygeographybiologyscoreandrank
WHERE
geographyRank <=1000
GROUP BY
  classNumber) AS a) AS top1000 USING (classNumber)


