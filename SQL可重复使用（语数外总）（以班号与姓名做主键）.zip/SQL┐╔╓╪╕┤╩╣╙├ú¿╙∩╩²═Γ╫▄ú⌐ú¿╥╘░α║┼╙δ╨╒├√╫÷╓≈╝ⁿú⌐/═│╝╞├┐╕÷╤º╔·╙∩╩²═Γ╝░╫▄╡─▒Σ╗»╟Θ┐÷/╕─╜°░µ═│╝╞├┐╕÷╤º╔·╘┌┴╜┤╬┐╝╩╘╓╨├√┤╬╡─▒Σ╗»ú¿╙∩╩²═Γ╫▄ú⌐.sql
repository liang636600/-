/*
作用：统计每一个学生在两次考试中名次变化情况
得到的表actualstudentrankchangelast列名
classNumber	NAME	ChineseRank1	ChineseRank2	ChineseRankChange	
MathRank1	MathRank2	MathRankChange	EnglishRank1	EnglishRank2	EnglishRankChange	
totalRank1	totalRank2	totalRankChange

使用要求：1.在步骤一中需要使用的表（（（actualscore列名（这张表中实际上只需要用到ChineseRank，MathRank，EnglishRank，totalRank）
classNumber	NAME	firstChinese	firstMath	firstEnglish	
middleChinese	middleMath	middleEnglish	
endChinese	endMath	endEnglish	
ActualChinese	ChineseRank	
ActualMath	MathRank	
ActualEnglish	
EnglishRank	totalScore	totalRank

beforeschoolstudentrank（前面一次考试的学生成绩）列名
name	classNumber	Chinese	ChineseRank	Math	MathRank	English	EnglishRank	totalScore	totalRank）））


）））
使用时需要改变：beforeschoolstudentrank（前一次考试每个学生的成绩和排名表），actualscore（后一次考试每个学生的成绩及排名表）
*/


#先把两次成绩表关联起来,获得一个新的表（包含每个学生各科名次的变化情况），这里的1代表的是前一次的考试，2代表的是后一次的考试
#新的表中同一个学生的两次成绩名次（如语文）作差，产生一个学生名次变化的最终表（也是所需要的表）
#新的表的列名为
#classNumber	NAME	ChineseRank1	ChineseRank2	ChineseRankChange	
#MathRank1	MathRank2	MathRankChange	EnglishRank1	EnglishRank2	EnglishRankChange	
#totalRank1	totalRank2	totalRankChange

/*
使用时可以在前面加上INSERT INTO actualstudentrankchangelast这样就可以产生一个actualstudentrankchangelast表了（即学生排名变化表）
*/
SELECT
classNumber,NAME,beforeschoolstudentrank.ChineseRank AS ChineseRank1,actualscore.ChineseRank AS ChineseRank2,(beforeschoolstudentrank.ChineseRank-actualscore.ChineseRank) AS ChineseRankChange,
beforeschoolstudentrank.MathRank AS MathRank1,actualscore.MathRank AS MathRank2,(beforeschoolstudentrank.MathRank-actualscore.MathRank) AS MathRankChange,
beforeschoolstudentrank.EnglishRank AS EnglishRank1,actualscore.EnglishRank AS EnglishRank2,(beforeschoolstudentrank.EnglishRank-actualscore.EnglishRank) AS EnglishRankChange,
beforeschoolstudentrank.totalRank AS totalRank1,actualscore.totalRank AS totalRank2，,(beforeschoolstudentrank.totalRank -actualscore.totalRank) AS totalRankChange
FROM
beforeschoolstudentrank JOIN actualscore USING(classNumber,NAME);