/*
作用：统计每一个学生在两次考试中名次变化情况
得到的表结构列名


使用要求：1.在步骤一中需要使用的表（（（actualscore列名（这张表中实际上只需要用到ChineseRank，MathRank，EnglishRank，totalRank）
classNumber	NAME	firstChinese	firstMath	firstEnglish	
middleChinese	middleMath	middleEnglish	
endChinese	endMath	endEnglish	
ActualChinese	ChineseRank	
ActualMath	MathRank	
ActualEnglish	
EnglishRank	totalScore	totalRank

beforeschoolstudentrank（前面一次考试的学生成绩）列名
name	classNumber	Chinese	ChineseRank	Math	MathRank	English	EnglishRank	totalScore	totalRank）））

2.步骤二中需要使用（（（actualstudentrankchange(产生中间过程的表)列名：
classNumber	NAME	ChineseRank1	ChineseRank2	MathRank1	MathRank2	EnglishRank1	EnglishRank2	totalRank1	totalRank2）））

3.步骤三中需要使用（（（actualstudentrankchangelast中间过程表，列名：
classNumber	NAME	ChineseRank1	ChineseRank2	ChineseRankChange	MathRank1	MathRank2	MathRankChange	
EnglishRank1	EnglishRank2	EnglishRankChange	totalRank1	totalRank2	totalRankChange

）））
使用时需要改变：beforeschoolstudentrank，actualscore，actualstudentrankchange，actualstudentrankchangelast
*/


#1.先把两次成绩表关联起来,获得一个新的表，这里的1代表的是前一次的考试，2代表的是后一次的考试
#新的表的列名为classNumber	NAME	ChineseRank1	ChineseRank2	MathRank1	MathRank2	
#EnglishRank1	EnglishRank2	totalRank1	totalRank2

SELECT
classNumber,NAME,beforeschoolstudentrank.ChineseRank AS ChineseRank1,actualscore.ChineseRank AS ChineseRank2,
beforeschoolstudentrank.MathRank AS MathRank1,actualscore.MathRank AS MathRank2,
beforeschoolstudentrank.EnglishRank AS EnglishRank1,actualscore.EnglishRank AS EnglishRank2,
beforeschoolstudentrank.totalRank AS totalRank1,actualscore.totalRank AS totalRank2
FROM
beforeschoolstudentrank JOIN actualscore USING(classNumber,NAME);


#2.新的表中同一个学生的两次成绩名次（如语文）作差，产生一个学生名次变化的最终表（也是所需要的表）
#最终表的列名为
#classNumber	NAME	ChineseRank1	ChineseRank2	ChineseRankChange	
#MathRank1	MathRank2	MathRankChange	EnglishRank1	EnglishRank2	EnglishRankChange	
#totalRank1	totalRank2	totalRankChange

SELECT
classNumber,NAME,ChineseRank1,ChineseRank2,(ChineseRank1-ChineseRank2) AS ChineseRankChange,
MathRank1,MathRank2,(MathRank1-MathRank2) AS MathRankChange,
EnglishRank1,EnglishRank2,(EnglishRank1-EnglishRank2) AS EnglishRankChange,
totalRank1,totalRank2,(totalRank1-totalRank2) AS totalRankChange
FROM
actualstudentrankchange

#3.统计一个班上的名次的变化情况(这里使用每个学生的变化情况相加)
#产生一个每个班的各科总的语数外总成绩的变化情况
#列名：
#classNumber	ClassChineseChange	ClassMathChange	ClassEnglishChange	ClassTotalChange
SELECT
classNumber,SUM(ChineseRankChange) AS ClassChineseChange,SUM(MathRankChange) AS ClassMathChange,
SUM(EnglishRankChange)  AS ClassEnglishChange,SUM(totalRankChange) AS ClassTotalChange
FROM
actualstudentrankchangelast
GROUP BY
classNumber