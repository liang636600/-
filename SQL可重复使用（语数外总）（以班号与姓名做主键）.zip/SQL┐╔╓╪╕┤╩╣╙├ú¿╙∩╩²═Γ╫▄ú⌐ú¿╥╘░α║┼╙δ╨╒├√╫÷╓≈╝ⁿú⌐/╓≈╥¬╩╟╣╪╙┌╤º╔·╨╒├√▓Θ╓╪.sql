
#从入学考试中选出不在后来班（即第一期期末的班级）的同学
SELECT
*
FROM
beforeschooltest
WHERE (beforeschooltest.classNumber,beforeschooltest.name) NOT IN (
SELECT
stuAndClass.`classNumber`,stuAndClass.`name`
FROM
stuAndClass);

#第一期结束的学生name有没有重复的
SELECT
DISTINCT NAME
FROM
stuAndClass;

SELECT
stuAndClass.`name`
FROM
stuAndClass;
#查看一期结束后同名的学生及那个名字的人数
SELECT
stuAndClass.`name`,COUNT(stuAndClass.`name`) AS num
FROM
stuAndClass
GROUP BY
stuAndClass.`name`
HAVING COUNT(stuAndClass.`name`) > 1;

#查看入学考试同名的学生和人数
SELECT
beforeschooltest.name, COUNT(beforeschooltest.name) AS num
FROM
beforeschooltest
GROUP BY
beforeschooltest.name
HAVING COUNT(beforeschooltest.name) > 1;

#查找重名学生在入学考试的成绩
SELECT
*
FROM
beforeschooltest
WHERE
beforeschooltest.name = '何娜' OR 
beforeschooltest.name = '岳鑫' OR 
beforeschooltest.name = '杨博' OR 
beforeschooltest.name = '李佳燕' OR 
beforeschooltest.name = '李星霖' OR 
beforeschooltest.name = '岳欢' OR 
beforeschooltest.name = '张钟月' OR 
beforeschooltest.name = '杨浩' OR 
beforeschooltest.name = '李佳玲' OR 
beforeschooltest.name = '何静'; 

#查找重名学生在综合后的成绩
SELECT
*
FROM
actualscore
WHERE
actualscore.name = '何娜' OR 
actualscore.name = '岳鑫' OR 
actualscore.name = '杨博' OR 
actualscore.name = '李佳燕' OR 
actualscore.name = '李星霖' OR 
actualscore.name = '岳欢' OR 
actualscore.name = '张钟月' OR 
actualscore.name = '杨浩' OR 
actualscore.name = '李佳玲' OR 
actualscore.name = '何静'; 

/*
更正入学考试各学生的成绩
方法：
主要方法是用stuAndClass表先与入学考试的成绩连接使用姓名（入学考试重名的情况先做排除），
再将这些同名学生的成绩连在后面组成一张以名字和班级为主键的入学考试成绩表
*/

#连接两个表
SELECT
stuAndClass.`name`,stuAndClass.`classNumber`,beforeschooltest.Chinese,beforeschooltest.Math,beforeschooltest.English
FROM
stuAndClass JOIN beforeschooltest USING(NAME);
#找出入学考试中不在纠正表中的学生

SELECT
*
FROM
  beforeschooltest
WHERE beforeschooltest.name NOT IN (
SELECT
stuAndClass.`name`
FROM
stuAndClass JOIN beforeschooltest USING(NAME)

岳贝芬
钟柱
刘久乐
杨利伟
杨康
何佳曼
魏晓春
马赵伦
杨健
