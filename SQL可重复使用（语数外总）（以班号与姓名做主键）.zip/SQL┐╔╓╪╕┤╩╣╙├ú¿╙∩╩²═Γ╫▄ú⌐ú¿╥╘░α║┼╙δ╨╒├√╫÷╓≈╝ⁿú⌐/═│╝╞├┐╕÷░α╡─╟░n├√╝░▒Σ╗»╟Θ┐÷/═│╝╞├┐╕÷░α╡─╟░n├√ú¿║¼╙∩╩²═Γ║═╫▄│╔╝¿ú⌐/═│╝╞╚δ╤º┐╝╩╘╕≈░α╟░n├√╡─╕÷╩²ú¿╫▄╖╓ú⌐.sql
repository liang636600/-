/*
作用：统计某次考试各班的总分前n名个数
得到的表结构列名classNumber	countNumtotal10	countNumtotal20	countNumtotal50	countNumtotal100	
countNumtotal200	countNumtotal300	countNumtotal400	countNumtotal500	countNumtotal600	
countNumtotal700	countNumtotal800	countNumtotal900	countNumtotal1000




使用要求：beforeschoolstudentrank(学生成绩表)，列名
name	classNumber	Chinese	ChineseRank	Math	MathRank	English	EnglishRank	totalScore	totalRank
使用时需要改变：beforeschoolstudentrank表名改变为成绩所在的表
*/
#统计入学考试班级的前n名（总分）,每次只需要改beforeschoolstudentrank表
SELECT * 
FROM
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal10
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <= 10
GROUP BY
  classNumber) AS a) AS top10



JOIN
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal20
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <= 20
GROUP BY
  classNumber) AS a) AS top20 USING(classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal50
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <= 50
GROUP BY
  classNumber) AS a) AS top50 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal100
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=100
GROUP BY
  classNumber) AS a) AS top100 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal200
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=200
GROUP BY
  classNumber) AS a) AS top200 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal300
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=300
GROUP BY
  classNumber) AS a) AS top300 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal400
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=400
GROUP BY
  classNumber) AS a) AS top400 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal500
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=500
GROUP BY
  classNumber) AS a) AS top500 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal600
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=600
GROUP BY
  classNumber) AS a) AS top600 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal700
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=700
GROUP BY
  classNumber) AS a) AS top700 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal800
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=800
GROUP BY
  classNumber) AS a) AS top800 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal900
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=900
GROUP BY
  classNumber) AS a) AS top900 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumtotal1000
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
totalRank <=1000
GROUP BY
  classNumber) AS a) AS top1000 USING (classNumber)


