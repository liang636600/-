/*
作用：统计某次考试各班的英语前n名个数
得到的表结构列名classNumber	countNumEnglish10	countNumEnglish20	countNumEnglish50	countNumEnglish100	
countNumEnglish200	countNumEnglish300	countNumEnglish400	countNumEnglish500	countNumEnglish600	
countNumEnglish700	countNumEnglish800	countNumEnglish900	countNumEnglish1000



使用要求：beforeschoolstudentrank(学生成绩表)，列名
name	classNumber	Chinese	ChineseRank	Math	MathRank	English	EnglishRank	totalScore	totalRank
使用时需要改变：beforeschoolstudentrank表名改变为成绩所在的表
*/
SELECT * 
FROM
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish10
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <= 10
GROUP BY
  classNumber) AS a) AS top10



JOIN
(SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish20
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <= 20
GROUP BY
  classNumber) AS a) AS top20 USING(classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish50
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <= 50
GROUP BY
  classNumber) AS a) AS top50 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish100
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=100
GROUP BY
  classNumber) AS a) AS top100 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish200
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=200
GROUP BY
  classNumber) AS a) AS top200 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish300
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=300
GROUP BY
  classNumber) AS a) AS top300 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish400
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=400
GROUP BY
  classNumber) AS a) AS top400 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish500
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=500
GROUP BY
  classNumber) AS a) AS top500 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish600
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=600
GROUP BY
  classNumber) AS a) AS top600 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish700
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=700
GROUP BY
  classNumber) AS a) AS top700 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish800
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=800
GROUP BY
  classNumber) AS a) AS top800 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish900
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=900
GROUP BY
  classNumber) AS a) AS top900 USING (classNumber)


JOIN 
(
SELECT
classNumber,(CASE 
            WHEN number IS NULL THEN 0
            ELSE number
            END) AS countNumEnglish1000
FROM
classNum NATURAL LEFT JOIN (SELECT
   classNumber,COUNT(*) AS number
FROM
  beforeschoolstudentrank
WHERE
EnglishRank <=1000
GROUP BY
  classNumber) AS a) AS top1000 USING (classNumber)


