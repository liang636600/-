#统计某一次考试的个人成绩排名`actualbeforeschooltest`
#actualbeforeschooltest表的要求：列名为NAME，classNumber，Chinese，Math，English
#产生一个列名为NAME，classNumber，Chinese，ChineseRank，Math，MathRank，English，EnglishRank，totalScore，totalRank的表
#totalScore在这张表里面是采用了(Chinese * 0.4 + Math*0.5+English*0.1)得到

#复用此表要求改变16行的(Chinese * 0.4 + Math*0.5+English*0.1) AS totalScore,和17行的rank() over (ORDER BY ((Chinese * 0.4 + Math*0.5+English*0.1)) DESC) AS totalRank
#还有改变19行的表名actualbeforeschooltest
SELECT
NAME,classNumber,
Chinese,
rank() over (ORDER BY ((Chinese)) DESC) AS ChineseRank,
Math,
rank() over (ORDER BY ((Math)) DESC) AS MathRank,
English,
rank() over (ORDER BY ((English)) DESC) AS EnglishRank,
(Chinese * 0.4 + Math*0.5+English*0.1) AS totalScore,
rank() over (ORDER BY ((Chinese * 0.4 + Math*0.5+English*0.1)) DESC) AS totalRank
FROM
actualbeforeschooltest;

/*
#这段代码是自动插入数据
#要求actualbeforeschooltest作为原始表，beforeschoolstudentrank作为最终表，这两个表需要提前建好
INSERT INTO beforeschoolstudentrank
(SELECT
NAME,classNumber,
Chinese,
rank() over (ORDER BY ((Chinese)) DESC) AS ChineseRank,
Math,
rank() over (ORDER BY ((Math)) DESC) AS MathRank,
English,
rank() over (ORDER BY ((English)) DESC) AS EnglishRank,
(Chinese * 0.4 + Math*0.5+English*0.1) AS totalScore,
rank() over (ORDER BY ((Chinese * 0.4 + Math*0.5+English*0.1)) DESC) AS totalRank
FROM
actualbeforeschooltest);
*/